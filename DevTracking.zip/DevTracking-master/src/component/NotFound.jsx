import React from "react";

const NotFound = () => {
  return (
    <>
      <div className="absolute top-0 right-0">
        <h1>Github User Not Exist</h1>
      </div>
    </>
  );
};

export default NotFound;
