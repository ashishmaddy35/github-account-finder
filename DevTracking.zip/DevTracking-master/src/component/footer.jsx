import React from 'react'

const footer = () => {
  return (
    <>
      <div className="flex justify-center mt-5 mb-5 items-center">
        <p>Made with ❤️ by <span className='text-green-500 font-bold'>Ashish Madheshiya</span></p>
      </div>
    </>
  )
}

export default footer
